﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.IconButton2 = New FontAwesome.Sharp.IconButton()
        Me.IconPictureBox1 = New FontAwesome.Sharp.IconPictureBox()
        Me.TxtName = New System.Windows.Forms.TextBox()
        Me.TxtPW = New System.Windows.Forms.TextBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.BtnLog = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnCan = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        CType(Me.IconPictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'IconButton2
        '
        Me.IconButton2.IconChar = FontAwesome.Sharp.IconChar.X
        Me.IconButton2.IconColor = System.Drawing.Color.Black
        Me.IconButton2.IconFont = FontAwesome.Sharp.IconFont.Solid
        Me.IconButton2.Location = New System.Drawing.Point(799, 30)
        Me.IconButton2.Name = "IconButton2"
        Me.IconButton2.Size = New System.Drawing.Size(48, 40)
        Me.IconButton2.TabIndex = 1
        Me.IconButton2.UseVisualStyleBackColor = True
        '
        'IconPictureBox1
        '
        Me.IconPictureBox1.BackColor = System.Drawing.Color.MediumPurple
        Me.IconPictureBox1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.IconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.UserAlt
        Me.IconPictureBox1.IconColor = System.Drawing.SystemColors.ControlText
        Me.IconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconPictureBox1.IconSize = 244
        Me.IconPictureBox1.Location = New System.Drawing.Point(273, 164)
        Me.IconPictureBox1.Name = "IconPictureBox1"
        Me.IconPictureBox1.Size = New System.Drawing.Size(256, 244)
        Me.IconPictureBox1.TabIndex = 2
        Me.IconPictureBox1.TabStop = False
        '
        'TxtName
        '
        Me.TxtName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtName.ForeColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.TxtName.Location = New System.Drawing.Point(137, 510)
        Me.TxtName.Name = "TxtName"
        Me.TxtName.Size = New System.Drawing.Size(499, 31)
        Me.TxtName.TabIndex = 3
        Me.TxtName.Text = "Username"
        '
        'TxtPW
        '
        Me.TxtPW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPW.ForeColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.TxtPW.Location = New System.Drawing.Point(137, 582)
        Me.TxtPW.Name = "TxtPW"
        Me.TxtPW.Size = New System.Drawing.Size(499, 31)
        Me.TxtPW.TabIndex = 4
        Me.TxtPW.Text = "Password"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Font = New System.Drawing.Font("Arial", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox1.Location = New System.Drawing.Point(150, 673)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(279, 36)
        Me.CheckBox1.TabIndex = 5
        Me.CheckBox1.Text = "Remember | ចងចាំ"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'BtnLog
        '
        Me.BtnLog.Location = New System.Drawing.Point(150, 766)
        Me.BtnLog.Name = "BtnLog"
        Me.BtnLog.Size = New System.Drawing.Size(223, 54)
        Me.BtnLog.TabIndex = 6
        Me.BtnLog.Text = "Login"
        Me.BtnLog.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(347, 907)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(116, 37)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Sign Up"
        '
        'BtnCan
        '
        Me.BtnCan.Location = New System.Drawing.Point(433, 766)
        Me.BtnCan.Name = "BtnCan"
        Me.BtnCan.Size = New System.Drawing.Size(223, 54)
        Me.BtnCan.TabIndex = 8
        Me.BtnCan.Text = "Cancel"
        Me.BtnCan.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BtnCan)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.BtnLog)
        Me.Panel1.Controls.Add(Me.CheckBox1)
        Me.Panel1.Controls.Add(Me.TxtPW)
        Me.Panel1.Controls.Add(Me.TxtName)
        Me.Panel1.Controls.Add(Me.IconPictureBox1)
        Me.Panel1.Controls.Add(Me.IconButton2)
        Me.Panel1.Location = New System.Drawing.Point(5, 6)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(879, 1036)
        Me.Panel1.TabIndex = 9
        '
        'FrmLogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MediumPurple
        Me.ClientSize = New System.Drawing.Size(883, 1047)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "FrmLogin"
        Me.Text = "FrmLogin"
        CType(Me.IconPictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents IconButton2 As FontAwesome.Sharp.IconButton
    Friend WithEvents IconPictureBox1 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents TxtName As TextBox
    Friend WithEvents TxtPW As TextBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents BtnLog As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents BtnCan As Button
    Friend WithEvents Panel1 As Panel

    Private Sub BtnCan_Click(sender As Object, e As EventArgs) Handles BtnCan.Click
        Me.Close()

    End Sub

    Private Sub BtnLog_Click(sender As Object, e As EventArgs) Handles BtnLog.Click
        Dim username As String = TxtName.Text
        Dim password As String = TxtPW.Text

        If username = "admin" And password = "123" Then
            FrmDashboard.Show()
            Me.Hide()
        ElseIf username = "user" And password = "123" Then
            FrmStudent.Show()
            Me.Hide()
        Else
            MessageBox.Show("Invalid username or password.")
        End If
    End Sub

    Private Sub IconButton2_Click(sender As Object, e As EventArgs) Handles IconButton2.Click
        Me.Close()

    End Sub
End Class
